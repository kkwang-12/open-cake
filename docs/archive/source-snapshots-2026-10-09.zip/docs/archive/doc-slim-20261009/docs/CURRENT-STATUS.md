# 当前项目状态

更新：2026-10-09（Asia/Hong_Kong）。本文件为日常接手入口；先核对Git与相关源码。历史记录不代表本轮执行授权，状态变化后替换对应条目。

## 当前交付与边界

- 顾客界面、本机购物流程及交易领域离线准备较完整；可离线工作推进至A07。
- 真实云接入集中在身份/部署与D04订单事务；未形成真实下单、支付、商家履约和退款闭环。
- 共享小程序仍为development/shell，旧演示默认关闭。客户端云接口仅user.me/store.health；订单列表、详情、成功页、商家管理仍为占位。
- 商品/购物袋/收藏/地址为开发样例或本机草稿，不能当成云账号同步功能。
- 用户确认的UI按当前源码保留；调整时读UI-TYPOGRAPHY，最终视觉由用户真机确认。

## 当前关键任务：D04正式订单事务

已完成：
- 隔离测试云事务探针16/16（2026-10-08）：原子写、逐写回滚、幂等、最后库存/时段竞争、独立容量、唯一冲突。
- 正式订单业务写入预算模块及订单文档session映射，本地通过；包含未提交成果。

下一项：
- 验证真实SDK对只读依赖变化和空查询的提交保护，落实protectReads/findOrderByNumber；不能用本地快照保护或空hook替代。
- 确认完整读写/保护/重试预算及购买行数限制；冻结隔离业务集合、索引、规则和测试数据，再验正式订单保存、回滚、并发和原key恢复。
- 正式订单、完整谓词保护/平台预算、真实断网丢响应、真机和完整权限仍待验收。D04为PARTIAL。
- 历史探针限时授权已过期，不自行复用或延期。新云写入/部署/真实资金按当前用户授权执行。

本任务按需阅读：
- [订单session](D04-ORDER-DOCUMENT-SESSION-2026-10-09.md)
- [订单预算](D04-ORDER-WRITE-BUDGET-2026-10-09.md)
- [真实探针结果](D04-CLOUD-REPAIR-2026-10-08.md)
- 源码：cloudfunctions/_shared/order-document-session.js、order-write-budget.js、order-transaction-service.js、cloud-document-transaction.js。

## 云环境（2026-10-09只读核实）

- AppID：wx154f791a17268ace；上海NoSQL。
- development：cloudbase-d8gwtxzm64150b7e0；user/store及2个身份/配置验收函数Active。
- 开发集合仅users（1）、admin_roles（0）、audit_logs（0）；正式交易集合未建齐。
- test：dinner-cook-test-d5e320u981ec341；jjl-d04-probe Active，3个探针集合。共享运行配置test仍为空，隔离工程验收不等于顾客页面已接云。
- production：共享配置为空，未在本轮核实生产资源/审核状态。

## 后续关键路径与资料

1. D04正式订单事务及权限/预算证据。
2. 正式商品、库存与门店配置；接目录/购物袋/地址/时段/报价/订单云接口与现有页面。
3. 核实商户及支付方案，真实收退款/通知/恢复；真实管理员与商家页面，打通自取/配送闭环。
4. Q01–Q08完整联调、资金/权限/并发/弱网/双平台真机、运维恢复与发布资料。

资料缺项：正式SKU/实拍/数量留言上限、库存/回补规则、提前量/预约窗口/支付保留时长、电话/可信位置、取餐码政策、管理员身份、商户关联/支付方案、客服/隐私/售后与实付安排。细则按需查EXTERNAL-DEPENDENCIES，不为继续开发虚构默认经营值。

## 最近验证与日常命令

- 2026-10-09流程优化后：摘要入口完整本地1025/1025通过，D04选定16/16通过；静态391文件通过；主包/features/legacy源估算1392/153/45 KiB，实际包以微信编译为准。
- 完整结果：[本轮全套TAP](qa/local-checks/tests-1791509024272-27428.tap)；此前[审查回归日志](qa/project-readiness-2026-10-09/tests-verified.log)保留。首次沙箱HTTP连接EACCES已在允许本机连接的环境完整复核。
- 日常相关测试：`node scripts/test-brief.js tests/具体.test.js`；完整回归：`node scripts/test-brief.js`；静态：`node scripts/check.js`。
- brief入口仅缩短聊天输出，执行选定文件中的全部测试，非零退出/失败/跳过/取消均不会报通过。原始日志在docs/qa/local-checks（忽略追踪），正式阶段证据仍用原验收脚本。

## 历史按需入口

- [本轮项目审查](PROJECT-READINESS-REVIEW-2026-10-09.md)
- [完整交接历史](HANDOFF-HISTORY-2026-10-09.md)
- 67任务补云验收细目：CLOUD-BACKFILL-TRACKER-2026-10-08；需求/字段/接口只在对应变更时查DEVELOPMENT-PLAN、DATA_MODEL、API_CONTRACT/API_NETWORK。

执行优化：默认单agent，按范围验证，相关源码优先；无新实现/风险不重复全套，不为常规小步新增长报告。此规则不降低交易正确性及真实验收要求。
