# D04 正式订单数据库 session 映射

本轮完成 `cloudfunctions/_shared/order-document-session.js`，连接已有订单服务与文档事务基础层。它是内部服务端模块，没有新增客户端 handler，没有部署或写入云数据。D04 整体仍为 PARTIAL。

## 当前实现

- 固定映射 users / idempotency_records / checkout_quotes / stores / store_config / carts / products / skus / addresses / inventory_resources / slot_inventory / orders / order_items / reservations / order_logs。
- 先核验报价所有权，再沿报价关联读取门店、现行配置、本人购物袋、选中行的商品与 SKU、库存、预约时段及配送地址。相同文档读取去重；不读取完整目录、不扫描全部库存、不跟随他人报价继续读取私有引用。
- 读取现行选中行及 SKU 的库存需求，并纳入报价记录的资源需求；由原有报价重验拒绝版本/内容变化，不拿旧报价快照替代当前数据库商品。
- 资源计数通过 versioned update 修改；订单头/明细/预留/日志/回执使用显式新增；报价消费保持 ACTIVE、未消费、未过期、本人同店约束，并将 patch.version 交给基础层统一递增。
- 构造必须传入 `protectReads`、`findOrderByNumber`、正整数 `maxReadDocuments`，缺少任一项直接拒绝。未提供默认 true 或空查询的降级实现。
- 新增 `assertReplayReads` 订单服务义务：幂等回放也必须保护本次读取的用户、回执和订单，不能绕过提交前读取保护。

## SDK 提供方仍须实现的义务

这些 hook 尚未连接真实 SDK，函数存在不等于通过云验收。

`protectReads(documentSnapshots, conditions, queryPredicates)` 必须使用**同一个事务**，保护所有已读文档的内容/版本和不存在状态直到提交。构造 session 应在每次 SDK 重试回调中重新执行，不能复用前一尝试的读取缓存。不能用立即重新读取或比较版本就声称提交前安全，也不能忽略幂等回放的用户禁用/权限变更。

`findOrderByNumber(orderNo)` 必须在同一事务执行受控精确查询，真实 orders.orderNo 唯一索引仍是最终写入约束。session 将查询条件、结果或空结果提交给 protectReads；完整谓词保护需实际验证，不能只保护已存在的文档。

`maxReadDocuments` 仅限制 session 加载的不同文档数，不包含基础层新增前的缺失检查、查询返回、保护写入或重试，因此不是完整平台事务预算。值必须由服务端配置，测试夹具 50 不是正式上限。

正式 handler 还需绑定原生身份、正确 EnvId、可验证商品图片和配送位置、正式经营配置、部署级限额及错误投影。当前服务输出继续 `cloudVerified:false / checkoutAllowed:false / paymentAllowed:false`。

## 验证

新增 10 项 SDK 形状的本地执行器测试：自取/配送完整 9 次业务写入、9 个故障位置整体回滚、他人报价早期拒绝、读取上限、保护失败、缺配置/伪造 principal、商品变化及他人地址/袋拒绝、无副作用回放、回放保护失败、去重及不加载无关数据、无效订单号查询结果拒绝。

夹具的事务暂存、读取保护和配送可信位置均为显式测试实现，不是云端并发或地图真实性证据。全套 **1025/1025**、静态 **389** 个文件通过；主包/features/legacy源估算1392/153/45 KiB。日志 `qa/d04-cloud/local-session-20261009/tests.txt`。此前 16/16 云探针结果不扩展为本次正式订单通过。

CloudBase 语义复核：本模块无身份/环境/密钥回显，不新增 Web auth guard；复用受控 principal 与 owner 校验。完整读取快照只交给内部提供方，不能进入客户端响应或普通日志。

## 下一项

先实测真实 SDK 对只读依赖变化和空查询的提交保护，再确定 protectReads 的真实实现和预算；冻结隔离业务集合/索引/规则清单后执行正式订单云验收。不要直接传入 `protectReads:()=>true` 部署本模块。
