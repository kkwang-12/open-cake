> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### audit_logs

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| actor: ActorRef | 是 / 无 | 真实服务端身份 | 固定 | 内部 |
| environment / appId: S | A01 是 / 无 | 服务端绑定；不取用户输入 | 固定 | 内部 |
| action: S | 是 / 无 | 角色 / 配置 / 目录 / 财务处置等动作 | 固定 | 内部 |
| storeId: ID? | 是 / null | 全局初始化可 null | 固定 | 内部 |
| storeIds: ID[] | A01 是 / 无 | 完整目标范围；多门店 storeId=null 不等于全局可读 | 固定 | 内部 |
| target: AuditTarget | 是 / 无 | 目标实体与版本 | 固定 | 内部 |
| changes: AuditChange[] | 是 / [] | 只保存允许审计的脱敏标量差异 | 固定 | 内部 |
| reason: S | 是 / 无 | 操作依据 | 固定 | 内部 |
| requestId: S | 是 / 无 | 追踪 | 固定 | 内部 |
| outcome: E | 是 / 无 | SUCCEEDED / REJECTED / FAILED | 固定 | 内部 |

资金与订单日志均追加，修正以新记录关联旧记录；不得擦除历史事实。
