> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### payments

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| orderId: ID | 是 / 无 | orders；一个订单可有关闭后的重试意图 | 固定 | 内部 |
| ownerId: ID | 是 / 无 | 订单本人；来源身份映射 | 固定 | 内部 |
| provider: S | 是 / 无 | 选定真实接入方案，不预设平台参数 | 固定 | 内部 |
| merchantId: S | 是 / 无 | 真实商户绑定 | 固定 | 内部 |
| appId: S | 是 / 无 | 与平台结果核对 | 固定 | 内部 |
| outTradeNo: S | 是 / 服务端生成 | 商户侧唯一；重试不变更同一意图单号 | 固定 | 内部 |
| transactionId: S? | 是 / null | 可信平台交易号；全局去重 | 一次 | 内部 |
| currency: E | 是 / CNY | 对应订单 | 固定 | 履约投影 |
| amountCents: C+ | 是 / 无 | 分，必须等于订单 totalCents | 固定 | 履约投影 |
| status: E | 是 / PENDING | PENDING / PAID / CLOSED / EXCEPTION；非订单 UNPAID | 可改按资金证据 | 履约投影 |
| accountingState: E | 是 / UNAPPLIED | UNAPPLIED / APPLIED / QUARANTINED；APPLIED 须可信成功且只入账一次 | 可改受控 | 内部 |
| expiresAt: T | 是 / 无 | <= 订单付款截止 | 固定 | 内部 |
| confirmedAt: T? | 是 / null | 平台原成功时间；精度见事件，不伪造原始毫秒 | 一次 | 履约投影 |
| closedAt: T? | 是 / null | 可信关闭时间，不是客户端退出 | 一次 | 内部 |
| lastEventId: ID? | 是 / null | payment_events | 可改 | 内部 |
