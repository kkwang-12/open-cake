> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### products

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| storeId: ID | 是 / 无 | stores | 固定 | 公开 |
| categoryCode: E | 是 / 无 | categories.code 三分类之一 | 固定 | 公开 |
| name: S | 是 / 无 | 正式名称 | 可改 | 公开 |
| description: S | 是 / 空串 | 展示文本，无执行内容 | 可改 | 公开 |
| images: MediaRef[] | 是 / [] | 发布要求有效素材；空值只供草稿 | 可改 | 公开 |
| optionGroups: OptionGroup[] | 是 / [] | 允许空规格；不能推导不存在 SKU | 可改 | 公开 |
| messagePolicy: MessagePolicy? | 是 / null | 发布时 null 表示不支持留言；DRAFT 待配置须保留阻塞，不得自动发布；不能从分类猜上限 | 可改 | 公开 |
| minLeadTimeMinutes: N? | 是 / null | 分钟；发布前明确，包括允许 0 的决定 | 可改 | 公开 |
| status: E | 是 / DRAFT | DRAFT / ON_SALE / OFF_SALE / ARCHIVED | 可改 | 公开仅 ON_SALE |
| sortOrder: N | 是 / 0 | 展示顺序 | 可改 | 公开 |
