> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### payment_events

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| provider: S | 是 / 无 | 与对应资金意图核对 | 固定 | 内部 |
| providerEventId: S? | 是 / null | 平台提供则保存；不同事件仍按交易号去重 | 固定 | 内部 |
| source: E | 是 / 无 | NOTIFICATION / QUERY / RECONCILIATION | 固定 | 内部 |
| kind: E | 是 / 无 | PAYMENT / REFUND / CLOSE | 固定 | 内部 |
| paymentId: ID? | 是 / null | 未匹配证据允许 null，进入隔离 | 一次关联 | 内部 |
| refundId: ID? | 是 / null | 退款事件匹配后填 | 一次关联 | 内部 |
| receivedAt: T | 是 / 服务端当前时间 | UTC 毫秒 | 固定 | 内部 |
| evidence: MoneyEvidence | 是 / 无 | 只保存白名单核验事实；不保存私钥 / token | 固定 | 内部 |
| verificationStatus: E | 是 / UNVERIFIED | UNVERIFIED / VERIFIED / REJECTED；未验不入账 | 一次核验 | 内部 |
| processingStatus: E | 是 / RECEIVED | RECEIVED / APPLIED / DUPLICATE / QUARANTINED / RETRY | 可改 | 内部 |
| processedAt: T? | 是 / null | 处理结束时间 | 一次 | 内部 |
| errorCode: S? | 是 / null | 脱敏异常；核验失败不丢证据 | 可改 | 内部 |
