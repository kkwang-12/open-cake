> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### cancellation_requests

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| orderId: ID | 是 / 无 | orders；同订单最多一个 PENDING 申请 | 固定 | 履约 |
| ownerId: ID | 是 / 无 | 与订单 ownerId 一致 | 固定 | 本人 |
| status: E | 是 / PENDING | PENDING / APPROVED / REJECTED | 一次审批 | 履约 |
| reason: S | 是 / 无 | 本人申请原因 | 固定 | 履约 |
| reviewerId: ID? | 是 / null | 审批时有当前本店权限的 users | 一次 | 内部 |
| reviewedAt: T? | 是 / null | 决定时间 | 一次 | 履约 |
| reviewReason: S? | 是 / null | 审批 / 拒绝理由 | 一次 | 履约 |
| approvedRefundCents: C? | 是 / null | 分；APPROVED 必填可为 0；其他 null | 一次 | 履约 |
| refundId: ID? | 是 / null | 正金额审批关联 refunds；零金额保持 null | 一次 | 内部 |
| requestLogId: ID | A06 是 / 无 | 原 REQUEST_CANCELLATION order_logs，确定性 request ID 绑定此日志 / 环境 / app / 订单 | 固定 | 内部 |
| reviewLogId: ID? | A06 是 / null | APPROVE_CANCELLATION / REJECT_CANCELLATION order_logs | 一次 | 内部 |

申请不改变 orderStatus，商家审批须读当前订单；履约竞争可能使申请无法批准，显式拒绝并留记录，不静默撤销。
