> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### admin_roles

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| subjectId: ID | 是 / 无 | users；初始身份 E12 待确认 | 固定 | 内部 |
| environment / appId: S | A01 是 / 无 | 服务端绑定隔离环境 / 应用 | 固定 | 内部 |
| storeIds: ID[] | 是 / 无 | 非空门店范围；A01 请求仅提出候选，服务端重验委派范围 / 门店 | A01 固定；重授权新记录 | 内部 |
| capabilities: S[] | 是 / [] | 六项词表；A01 创建须非空并在授权者范围内 | A01 固定；重授权新记录 | 内部 |
| status: E | 是 / ACTIVE | ACTIVE / REVOKED | 可改并审计 | 内部 |
| grantedBy: ActorRef | 是 / 无 | 受控初始化或有角色管理权限者 | 固定 | 内部 |
| grantSource: E | A01 是 / 无 | BOOTSTRAP / DELEGATED | 固定 | 内部 |
| grantAuditId: ID | A01 是 / 无 | audit_logs；角色 _id 绑定 environment / appId / 此 ID | 固定 | 内部 |
| revokedAt: T? | 是 / null | 撤销生效；每次敏感操作重查 | 一次 | 内部 |
| revocationAuditId: ID? | A01 是 / null | 撤销审计；撤销与 version 0→1 同事务填入 | 一次 | 内部 |

A01 当前只新建 ACTIVE / version 0 与一次撤销到 REVOKED / version 1，不原地编辑范围 / 能力。初始化 audit ID 为环境 / 应用永久唯一标记，不能 TTL 删除或删除角色后重置。D06 原基础 guard 及其他历史夹具未自动迁移；A01 严格角色 / 时间 / scope 约束与真实适配器要求见 [A01](../../../A01-ADMIN-AUTHORIZATION.md)。未建库。
