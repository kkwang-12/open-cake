> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### skus

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| storeId: ID | 是 / 无 | 与 product 相同 | 固定 | 公开 |
| productId: ID | 是 / 无 | products | 固定 | 公开 |
| description: S | 是 / 无 | 规格显示文本 | 可改 | 公开 |
| selectedOptions: SelectedOption[] | 是 / [] | groupCode 每组唯一；合法组合只来自明确 SKU | 固定；换组合建新 SKU | 公开 |
| currency: E | 是 / CNY | 仅 CNY | 固定 | 公开 |
| unitPriceCents: C+? | 是 / null | 分；null 草稿不可买；正式价 > 0 | 可改 | 公开 |
| minQuantity: P? | 是 / null | 件 / 份等销售数量；待商家确认 | 可改 | 公开 |
| maxQuantity: P? | 是 / null | 不小于 minQuantity；不替代库存 | 可改 | 公开 |
| stockRequirements: ResourceRequirement[] | 是 / [] | 非空且资源单位明确后才允许销售 | 可改 | 内部 |
| status: E | 是 / DRAFT | DRAFT / ON_SALE / OFF_SALE / ARCHIVED；产品亦须可售 | 可改 | 公开仅可售 |
