> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### addresses

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| ownerId: ID | 是 / 无 | users | 固定 | 本人 |
| receiverName: S | 是 / 无 | 服务端验证联系人 | 可改 | 本人 |
| phone: S | 是 / 无 | 电话字符串；不能转数值 | 可改 | 本人 |
| province: S | 是 / 无 | 行政区文字 | 可改 | 本人 |
| city: S | 是 / 无 | 行政区文字 | 可改 | 本人 |
| district: S | 是 / 无 | 行政区文字 | 可改 | 本人 |
| regionCodes: RegionCodes | 是 / 无 | 文字与编码核对；缺编码可显式 null | 可改 | 本人 |
| detail: S | 是 / 无 | 完整地址；不进入公开日志 | 可改 | 本人 |
| location: Location? | 是 / null | 未定位时不得用虚构坐标 | 可改 | 本人 |
| deletedAt: T? | 是 / null | 软删除；不得改订单地址快照 | 一次 | 本人 |

默认地址仅 users.defaultAddressId，不保存竞争的 isDefault。删除默认地址与清空指针须原子；不隐式选另一个地址。设置默认时验证本人 / 未删除 / version。
