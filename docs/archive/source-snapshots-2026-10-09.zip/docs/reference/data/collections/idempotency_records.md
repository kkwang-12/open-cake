> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### idempotency_records

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| actorScope: S | 是 / 无 | 可信 owner / 系统处理器身份隔离范围 | 固定 | 内部 |
| command: S | 是 / 无 | 命令隔离范围 | 固定 | 内部 |
| key: S | 是 / 无 | 调用方幂等键；同 scope/command/key 唯一 | 固定 | 内部 |
| requestFingerprint: S | 是 / 无 | 规范化命令摘要；同键不同输入拒绝 | 固定 | 内部 |
| status: E | 是 / IN_PROGRESS | IN_PROGRESS / SUCCEEDED / FAILED；锁租约 D04 定义 | 可改 | 内部 |
| result: CommandResult? | 是 / null | 可重放安全结果，不存电话 / 支付 token | 一次终结 | 内部 |
| leaseUntil: T? | 是 / null | 后台任务租约；不等于资金终结 | 可改受控 | 内部 |
| retentionUntil: T? | 是 / null | 保留策略待定；不能仅 TTL 删除资金唯一性证据 | 可改受控 | 内部 |
