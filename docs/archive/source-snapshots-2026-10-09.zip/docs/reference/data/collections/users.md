> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### users

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| environment: S | 是 / 无 | 当前隔离环境 | 固定 | 内部 |
| appId: S | 是 / 无 | 可信平台上下文 | 固定 | 内部 |
| openId: S | 是 / 无 | 同 appId、environment 唯一身份映射 | 固定 | 内部 |
| displayName: S | 是 / 空串 | 非鉴权依据 | 可改 | 本人 |
| avatar: MediaRef? | 是 / null | 不包含访问 token | 可改 | 本人 |
| defaultAddressId: ID? | 是 / null | 必须为本人未删除地址；单一指针 | 可改 | 本人 |
| status: E | 是 / ACTIVE | ACTIVE / DISABLED；禁用不删除历史关系 | 可改 | 内部 |
| privacyConsent: Consent? | 是 / null | 版本化同意记录；缺少时不能假装已同意 | 可改并留审计 | 本人 |
