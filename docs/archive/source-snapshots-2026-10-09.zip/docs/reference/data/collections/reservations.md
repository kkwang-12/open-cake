> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### reservations

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| orderId: ID | 是 / 无 | orders；与订单头 / 行同事务 | 固定 | 内部 |
| storeId: ID | 是 / 无 | 一致门店 | 固定 | 内部 |
| resourceKind: E | 是 / 无 | STOCK / SLOT | 固定 | 内部 |
| resourceId: ID | 是 / 无 | STOCK→inventory_resources；SLOT→slot_inventory | 固定 | 内部 |
| quantity: P | 是 / 无 | resource 单位，按整单聚合，不等同售价数量 | 固定 | 内部 |
| status: E | 是 / HELD | HELD / CONFIRMED / CONSUMED / RELEASED | 可改受控且不能重复释放 | 内部 |
| expiresAt: T | 是 / 无 | 初始支付占用截止；到期不代表可直接释放 | 固定 | 内部 |
| resolvedAt: T? | 是 / null | 消耗 / 释放提交时间 | 一次 | 内部 |
| resolutionLogId: ID? | 是 / null | order_logs | 一次 | 内部 |
