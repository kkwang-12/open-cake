> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### stores

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| name: S | 是 / 无 | 正式门店名 | 可改 | 公开 |
| address: S? | 是 / null | 正式实体店地址，缺失不发布 | 可改 | 公开 |
| phone: S? | 是 / null | 正式联系号码，缺失不发布 | 可改 | 公开 |
| timeZone: S? | 是 / null | IANA 时区；不继承客户端 / 执行机时区 | 可改 | 公开 |
| location: Location? | 是 / null | 配送定位依赖的可信门店位置 | 可改 | 公开仅必要位置 |
| status: E | 是 / DRAFT | DRAFT / OPEN / CLOSED / ARCHIVED | 可改 | 公开仅发布资料 |
| activeConfigId: ID? | 是 / null | 本店 PUBLISHED store_config | 可改 | 内部 |
