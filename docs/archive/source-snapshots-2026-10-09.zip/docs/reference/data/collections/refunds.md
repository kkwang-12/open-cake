> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### refunds

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| orderId: ID | 是 / 无 | orders | 固定 | 内部 |
| paymentId: ID | 是 / 无 | 已成功付款，原交易号可定位 | 固定 | 内部 |
| cancellationRequestId: ID? | 是 / null | 取消审批退款才有值 | 固定 | 内部 |
| approvalLogId: ID | 是 / 无 | order_logs；拒单 / 补偿也记录依据 | 固定 | 内部 |
| approvedBy: ActorRef | 是 / 无 | 商家审批或可信迟到款补偿处理器 | 固定 | 内部 |
| reason: S | 是 / 无 | 本次意图依据 | 固定 | 履约投影 |
| currency: E | 是 / CNY | 原付款币种 | 固定 | 履约投影 |
| amountCents: C+ | 是 / 无 | 分；不保存零金额意图 | 固定 | 履约投影 |
| outRefundNo: S | 是 / 服务端生成 | 唯一意图号；查询 / 重试复用 | 固定 | 内部 |
| providerRefundId: S? | 是 / null | 可信退款平台号 | 一次 | 内部 |
| status: E | 是 / PENDING | PENDING / FAILED / SUCCEEDED；成功不可倒退 | 可改按资金证据 | 履约投影 |
| budgetState: E | 是 / RESERVED | RESERVED / SETTLED / RELEASED；失败仍 RESERVED | 可改受控 | 内部 |
| settledAt: T? | 是 / null | 可信成功时间 | 一次 | 履约投影 |
| settledAtPrecisionMs: N? | 是 / null | P06 原成功时间精度 1 / 1000ms；成功必填，其他状态 null | 一次 | 内部 |
| lastEventId: ID? | 是 / null | payment_events | 可改 | 内部 |
| lastErrorCode: S? | 是 / null | 脱敏错误，无原始凭证 | 可改 | 内部 |

budgetState=RELEASED 仅供未来核实后受控处置，须审计与订单摘要同事务调整，D01 不提供该命令；当前不能调用方自行释放。退款意图终结后的订单 refundStatus 重算规则及处置流程须在 P06 完成，未经实现保持预算占用。
