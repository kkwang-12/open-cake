> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### order_logs

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| orderId: ID | 是 / 无 | orders | 固定 | 履约 |
| command: S | 是 / 无 | D01 命令或显式资金 / 资源领域动作 | 固定 | 内部 |
| actor: ActorRef | 是 / 无 | 可信执行者，不接受前端 role | 固定 | 内部 |
| before: TradeAxes? | 是 / 无 | 提交前状态 / 金额 / version；仅首次 ORDER_CREATED 为 null（此前无订单），其他命令必须交易轴 | 固定 | 内部 |
| after: TradeAxes | 是 / 无 | 提交后状态 / 金额 / version | 固定 | 内部 |
| requestId: S | 是 / 无 | 脱敏关联追踪，不是幂等键 | 固定 | 内部 |
| eventId: ID? | 是 / null | 资金动作关联 payment_events | 固定 | 内部 |
| reason: S | 是 / 空串 | 脱敏理由；不存电话 / 凭证 | 固定 | 履约投影 |
| publicMessage: S | 是 / 空串 | 审核过的订单进度文案 | 固定 | 履约 |
