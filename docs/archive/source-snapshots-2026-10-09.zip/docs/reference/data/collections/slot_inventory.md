> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### slot_inventory

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| storeId: ID | 是 / 无 | stores | 固定 | 内部 |
| fulfillment: E | 是 / 无 | PICKUP / DELIVERY 分开 | 固定 | 公开投影 |
| serviceDate: S | 是 / 无 | 门店当地 YYYY-MM-DD | 固定 | 公开投影 |
| timeZone: S | 是 / 无 | 对应发布配置 | 固定 | 公开投影 |
| startAt: T | 是 / 无 | UTC 毫秒 | 固定 | 公开投影 |
| endAt: T | 是 / 无 | > startAt；半开区间 [startAt,endAt) | 固定 | 公开投影 |
| policyVersion: S | 是 / 无 | 当前 TimePolicy.policyVersion；A05 可随新发布维护未来仍可约资源，版本 / 占用池 / 审计同事务；订单历史快照固定 | 受控发布维护；已开始资源不改 | 内部 |
| capacityUnit: S | 是 / 无 | SlotPolicy.unit，经确认后才能发布 | 固定 | 内部 |
| capacityTotal: N | 是 / 无 | 容量，允许 0 表示无可售名额 | 可改按资源事务 | 内部 |
| heldUnits: N | 是 / 0 | HELD 预留之和 | 可改按资源事务 | 内部 |
| confirmedUnits: N | 是 / 0 | CONFIRMED 之和 | 可改按资源事务 | 内部 |
| consumedUnits: N | 是 / 0 | CONSUMED 之和 | 可改按资源事务 | 内部 |
| status: E | 是 / CLOSED | OPEN / CLOSED；配置核验后开放 | 可改 | 公开投影 |
