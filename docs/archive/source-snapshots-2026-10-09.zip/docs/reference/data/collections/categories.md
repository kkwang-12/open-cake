> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### categories

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| code: E | 是 / 无 | 仅 CAKE / MINI_CAKE / BREAD；全局唯一 | 固定 | 公开 |
| nameZh: S | 是 / 无 | 对应 蛋糕 / 小蛋糕 / 面包 | 固定 | 公开 |
| nameEn: S | 是 / 无 | 对应 Cake / Mini Cake / Bread | 固定 | 公开 |
| sortOrder: N | 是 / 无 | 顺序；不派生新分类 | 可改 | 公开 |
| published: B | 是 / false | 仅发布记录公开 | 可改 | 公开 |
