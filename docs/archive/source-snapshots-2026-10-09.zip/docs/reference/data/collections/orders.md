> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### orders

含 D01 的全部交易字段，持久化时 id 由 _id 映射、version 已由通用字段定义；其余 ownerId/storeId/tradePolicyVersion/fulfillment/三轴/currency/totalCents/三个资金摘要沿用前表的类型、初值、约束与隐私。以下补齐事实 / 状态字段。

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| orderNo: S | 是 / 服务端生成 | 唯一展示编号，不是核销凭证 / 鉴权键 | 固定 | 履约 |
| quoteId: ID | 是 / 无 | checkout_quotes，反向 consumedOrderId 对应 | 固定 | 内部 |
| orderNote: S | 是 / 空串 | 订单备注，与逐行留言独立；长度待配置 | 固定 | 履约 |
| cartSelectionSnapshot: CartSelectionSnapshot | 是 / 无 | 创建时选中行证据 | 固定 | 内部 |
| cartRemovalSnapshot: CartRemovalSnapshot | 是 / 无 | O04 创建时从可信 Cart 捕获的精确移除证据，仅订单持有 | 固定 | 内部 |
| storeSnapshot: StoreSnapshot | 是 / 无 | 订单创建事实 | 固定 | 履约 |
| contactSnapshot: ContactSnapshot | 是 / 无 | 自提 / 配送联系人 | 固定 | 履约 |
| addressSnapshot: AddressSnapshot? | 是 / 无 | DELIVERY 对象；PICKUP null | 固定 | 履约 |
| appointmentSnapshot: AppointmentSnapshot | 是 / 无 | 时区与 UTC 区间 | 固定 | 履约 |
| deliverySnapshot: DeliverySnapshot | 是 / 无 | 服务端运费与范围证据 | 固定 | 履约投影 |
| subtotalCents: C+ | 是 / 无 | 分，订单行之和 | 固定 | 履约 |
| deliveryFeeCents: C | 是 / 无 | 分，与 deliverySnapshot.feeCents 一致 | 固定 | 履约 |
| paymentDeadlineAt: T | 是 / 无 | 资源占用截止；不晚于预约允许边界 | 固定 | 履约 |
| paidAt: T? | 是 / null | 经核验的成功时间下界；原平台时间 / 精度保留在事件，见 P03 | 一次 | 履约 |
| cancelledAt: T? | 是 / null | 合法取消提交时间 | 一次 | 履约 |
| completedAt: T? | 是 / null | 合法履约完成时间 | 一次 | 履约 |
| cancellationReason: S? | 是 / null | 取消时填，不混审批 / 退款原因 | 一次 | 履约 |
| pickupCredential: PickupCredential? | 是 / null | 仅自提；策略 E10 待确认 | 可改按核销契约 | 内部 |
