> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### checkout_quotes

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| ownerId: ID | 是 / 无 | users；客户端只能取本人报价 | 固定 | 本人 |
| storeId: ID | 是 / 无 | 与 facts.storeSnapshot.storeId 一致 | 固定 | 本人 |
| facts: OrderFacts | 是 / 无 | captureOrderFacts 返回结构；facts.quoteId = _id | 固定 | 履约 |
| resourceVersions: ResourceVersion[] | 是 / 无 | 当前资源版本 / 需求证明；非预留 | 固定 | 内部 |
| addressVersion: N? | 是 / 无 | DELIVERY 是来源地址版本；PICKUP null | 固定 | 内部 |
| expiresAt: T | 是 / 无 | > createdAt；TTL 来自发布配置 | 固定 | 本人 |
| status: E | 是 / ACTIVE | ACTIVE / CONSUMED / INVALIDATED；过期按时间判定 | 可改 | 本人 |
| consumedOrderId: ID? | 是 / null | 一份报价最多创建一个订单 | 一次 | 本人 |
