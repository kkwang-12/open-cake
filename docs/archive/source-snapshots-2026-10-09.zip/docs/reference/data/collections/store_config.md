> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### store_config

配置采用发布版本：发布后固定；修改生成新记录并切换 stores.activeConfigId，不能改历史版本。

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| storeId: ID | 是 / 无 | stores | 固定 | 内部 |
| configVersion: N | 是 / 无 | 本店单调唯一发布序号，与记录 version 区别 | 固定 | 内部 |
| status: E | 是 / DRAFT | DRAFT / PUBLISHED / RETIRED | 可改并审计 | 内部 |
| fulfillmentModes: E[] | 是 / [] | PICKUP / DELIVERY；发布非空 | 草稿可改；发布固定 | 公开投影 |
| timePolicy: TimePolicy? | 是 / null | 缺失不得报价 | 草稿可改；发布固定 | 公开投影 |
| deliveryRules: DeliveryRule[] | 是 / [] | 启用配送须有完整可判定规则 | 草稿可改；发布固定 | 公开投影 |
| cartLimits: CartLimits? | 是 / null | 缺限制不开放正式袋写入 | 草稿可改；发布固定 | 公开投影 |
| quoteTtlMinutes: P? | 是 / null | 分钟，待确认 | 草稿可改；发布固定 | 内部 |
| paymentHoldMinutes: P? | 是 / null | 分钟；须符合预约边界 | 草稿可改；发布固定 | 内部 |
| slotPolicy: SlotPolicy? | 是 / null | 容量 / 单位 / 回补语义待确认 | 草稿可改；发布固定 | 内部 |
| tradePolicyVersion: S | 是 / v1-2026-10-03 | 已冻结政策 | 草稿可改；发布固定 | 公开 |
| fulfillmentPolicyVersion: S | 是 / v1-fulfillment-2026-10-03 | 已确认履约政策，随配置版本保存 | 草稿可改；发布固定 | 公开 |
| publishedAt: T? | 是 / null | 发布校验通过后填 | 一次 | 内部 |
