> 集合字段定义；另读[通用字段](../04.md)。创建/部署状态不在此维护。

### order_items

| 字段 / 类型 | 必填 / 默认 | 约束 / 单位 | 可变性 | 隐私 |
|---|---|---|---|---|
| orderId: ID | 是 / 无 | orders；与订单头同事务创建 | 固定 | 履约 |
| position: N | 是 / 无 | 原快照 items 数组顺序，从 0 起，连续且唯一 | 固定 | 履约 |
| ItemSnapshot 各字段 | 是 / 无 | 下文逐字段展开；直接存行字段，不再嵌套 item | 固定 | 履约 |

数据库订单头 **不另存 items 数组**。captureOrderFacts 的 items 仅为原子创建载荷，落到 order_items 后是唯一历史明细。读模型按 position 聚合；不得通过两个入口独立改明细。外键 productId/skuId 仅溯源，读历史必须用快照。
