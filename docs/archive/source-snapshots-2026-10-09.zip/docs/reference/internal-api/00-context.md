# V1 接口契约：来源上下文

仅用于解释原设计来源，不用于判断当前状态或下一步。

# V1 接口契约

日期：2026-10-03。当前范围：已有最小云接口、D01–D07 内部工具，以及 D07 目标网络契约。完整目标 action / DTO / 权限 / 幂等 / 错误 / 分页 / 时序见 [API_NETWORK.md](../../API_NETWORK.md)；只有 user.me/store.health 有最小函数逻辑，目标业务接口尚未开放。

2026-10-04 B06 补充：本机 Checkout 输入仅用于 LOCAL_DRAFT_PREVIEW；内部 `resolveCheckoutSelection` 从可信 Cart 与目录重算选中行金额，不是正式 Quote 或部署 action。所选行版本及订单创建后精准移除 / 去重 / 补偿协议见 [B06-CHECKOUT-SELECTION.md](../../B06-CHECKOUT-SELECTION.md)。正式购买门禁保持关闭。

X01 补充：本机地址按 AppID 保存 LOCAL_DEVICE 草稿；内部 address-model / address-service 验证可信本人、地址与用户版本、默认指针、原子软删除 / 回执及不可变地址快照。没有云 handler；address.list 签名分页与完整 Profile 读模型仍待接入。当前手工地址 location / 编码为 null，不能作为配送通过证明。详见 [X01-ADDRESSES.md](../../X01-ADDRESSES.md)。

X02 补充：store-information 仅在 development / shell 展示 USER_CONFIRMED_REFERENCE、CONFIGURATION_PENDING 门店资料；LOCAL_DEVICE 履约 / 联系人草稿不是 Store / Quote DTO。内部 store-fulfillment 接受可信门店 / 已发布配置、当前版本、D06 principal 和配置后的 validatePhone，拒绝停业 / 禁用 / 客户端额外费用字段；自取无需地址且费用 0，配送仍待本人地址 / 位置 / 范围 / 时段核验。始终 checkoutAllowed=false，没有 store.get handler、SDK 或 allowlist 扩展。详见 [X02-STORE-FULFILLMENT.md](../../X02-STORE-FULFILLMENT.md)。

X03 补充（2026-10-05）：内部 evaluateDeliveryInput 仅接收 ID / 预期版本，可信 principal、快照及精确位置核验适配器由服务端提供；唯一 ACTIVE 20 km / 免费规则与实体版本绑定离线通过。返回 OFFLINE_DELIVERY_EVALUATION / 不可变地址快照 / 绑定摘要，不生成 evaluationId，checkoutAllowed=false，仍需云保存和时段核验。没有 delivery.evaluate handler 或 allowlist 扩展；本机只能显示待核验或地址失效。详见 [X03-DELIVERY-RANGE.md](../../X03-DELIVERY-RANGE.md)。

X04 补充（2026-10-05）：内部 readAppointmentAvailability 校验可信配置及本人购物袋选择，提前量取正式商品与门店最大值；按所查日期 / 模式读取真实容量记录，缺记录 UNVERIFIED、旧定义 STALE、FULL / CLOSED 均不可选。返回查询日期边界和时段白名单，capacityReserved=false / checkoutAllowed=false，摘要不是预约凭证。无 appointment.list handler 或 allowlist 扩展；本机门店参考只显示待配置说明。详见 [X04-APPOINTMENT-AVAILABILITY.md](../../X04-APPOINTMENT-AVAILABILITY.md)。

X05 补充（2026-10-05）：内部 quote-model 复用 D07 quote.create 白名单（lineVersion 转内部 expectedLineVersion），从可信商品 / 袋 / 库存 / 时段 / 配送数据重算并捕获 OrderFacts，生成 OFFLINE_QUOTE_PLAN 与待原子保存效果；报价不占资源。时效来自发布 quoteTtlMinutes 且不晚于提前量截止，过期 / 消费 / 事实或资源版本变化拒绝旧报价。公开 OFFLINE_QUOTE_PREVIEW 隐藏资源、袋与评估证据；没有 quote handler、云保存或 allowlist 扩展，checkoutAllowed=false。详见 [X05-TRUSTED-QUOTE.md](../../X05-TRUSTED-QUOTE.md)。

X06 / X07 补充（2026-10-05）：客户端 confirmation-session 仅准备未来 Quote 确认状态，当前没有网络适配器；ticket 失效阻止旧响应，错误 / 到期清旧报价，拒绝 OFFLINE_* 结果。submission-contract 仅生成不可调用 OFFLINE_ORDER_REQUEST_PLAN：order.create 严格 {quoteId, expectedQuoteVersion, idempotencyKey}；实际保存订单后才可 payment.create / state.get，当前全部保持未接通。未扩展 handler / allowlist。见 [X06 记录](../../X06-CHECKOUT-CONFIRMATION.md) / [阶段五验收](../../PHASE-5-REVIEW.md)。
